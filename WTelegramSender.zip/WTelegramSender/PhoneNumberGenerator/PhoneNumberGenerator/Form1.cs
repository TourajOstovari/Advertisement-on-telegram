﻿using System;
using System.Windows.Forms;

namespace PhoneNumberGenerator
{
    public partial class Form1 : Form
    {
        System.Numerics.BigInteger phone1, phone2;
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            phone1 = System.Numerics.BigInteger.Parse(string.Concat(Phone1.Text, Phone2.Text, Phone3.Text));
            phone2 = System.Numerics.BigInteger.Parse(string.Concat(Phone1_1.Text, Phone2_2.Text, Phone3_3.Text));
            while (phone1 <= phone2)
            {
                System.IO.File.AppendAllText(@"D:\Contacts.txt",string.Concat(textBox1.Text, phone1++,"\r\n"));
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox8.Text = textBox1.Text;
        }
    }
}
