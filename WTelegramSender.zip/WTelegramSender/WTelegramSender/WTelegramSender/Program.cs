﻿namespace WTelegramSender
{
    using System;
    using TL;
    using System.Threading.Tasks;
    using System.Linq;
    class Program
    {
        static string Config(string what)
        {
            switch (what)
            {
                case "api_id": return "1589451";
                case "api_hash": return "d6f1aba7d4bebdde2ddbe45989e9bf6d";
                case "phone_number": return "+989034750548";
                case "verification_code": Console.Write("Code: "); return Console.ReadLine();
                case "first_name": return "John";      // if sign-up is required
                case "last_name": return "Doe";        // if sign-up is required
                case "password": return "MaX1375";     // if user has enabled 2FA
                default: return null;                  // let WTelegramClient decide the default config
            }
        }
        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello, This is developed by Mr. Touraj Ostovari .... Year: 2022");
            System.Collections.Generic.List<string> contacts = System.IO.File.ReadAllLines(@"D:\Contacts.txt").ToList();
            string message = System.IO.File.ReadAllText(@"D:\msg.txt");

            using var client = new WTelegram.Client(Config); // or Client(Environment.GetEnvironmentVariable)
            await client.LoginUserIfNeeded();
            
            for (int i = 0; i < (int)contacts.Count; i++)
            {
                try
                {
                    var contact = await client.Contacts_ImportContacts(new[] { new InputPhoneContact { phone = contacts[i].Trim(), first_name = "UK", last_name = "Tester" } });
                    //var contact = await client.Contacts_ImportContacts(new[] { new InputPhoneContact { phone = "+447944134009", first_name = "UK", last_name = "Tester" } });
                    if(contact.retry_contacts.Length>0)
                         contact = await client.Contacts_ImportContacts(new[] { new InputPhoneContact { phone = contacts[i], first_name = "UK", last_name = "Tester" } });
                    Console.WriteLine("Maybe ... Contact added succesfully...");
                    object p = await client.SendMessageAsync(contact.users[contact.users.Keys.First()], message);
                    System.IO.File.AppendAllText(@"D:\Won.txt", string.Concat(contacts[i], "\r\n"));
                }
                catch (Exception)
                {
                    System.IO.File.AppendAllText(@"D:\Lost.txt", string.Concat(contacts[i], "\r\n"));
                }
                finally
                {
                    contacts.Remove(contacts[i]);
                    System.IO.File.Delete(@"D:\Contacts.txt");
                    System.Threading.Thread.Sleep(10000);
                    System.IO.File.AppendAllLines(@"D:\Contacts.txt",contacts);
                }
            }
        }
    }
}
